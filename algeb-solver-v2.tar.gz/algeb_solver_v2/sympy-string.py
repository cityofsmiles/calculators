global string
string = str("2*a*n+d*n**2-d*n")
