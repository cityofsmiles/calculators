global string
string = str("x")
