global string
string = str("k**4")
