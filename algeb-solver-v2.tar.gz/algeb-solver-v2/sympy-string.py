global string
string = str("q**3")
